import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';

export default function Index() {

  const router = useRouter();

  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Lista de Exercícios</Text>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => router.push('/home')}
      >
        <Text style={styles.textoBotao}>Maioridade</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botao}
        onPress={() => router.push('/home2')}
      >
        <Text style={styles.textoBotao}>Cálculo IMC</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({

  container:{
    flex:1,
    justifyContent:'center',
    alignItems:'center'
  },

  titulo:{
    fontSize:26,
    marginBottom:40
  },

  botao:{
    backgroundColor:'#4CAF50',
    padding:15,
    width:'70%',
    marginBottom:20,
    borderRadius:8
  },

  textoBotao:{
    color:'#fff',
    textAlign:'center',
    fontSize:18
  }

});