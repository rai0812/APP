import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function Home2() {

  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');

  function calcularIMC() {

    const imc = Number(peso) / (Number(altura) * Number(altura));
    let classificacao = '';

    if (imc < 18.5) {
      classificacao = 'Abaixo do peso';
    } 
    else if (imc < 25) {
      classificacao = 'Peso normal';
    } 
    else if (imc < 30) {
      classificacao = 'Sobrepeso';
    } 
    else if (imc < 35) {
      classificacao = 'Obesidade grau I';
    } 
    else if (imc < 40) {
      classificacao = 'Obesidade grau II';
    } 
    else {
      classificacao = 'Obesidade grau III';
    }

    alert(`IMC: ${imc.toFixed(2)}\n${classificacao}`);
  }

  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Calculadora de IMC</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite seu peso"
        keyboardType="numeric"
        onChangeText={setPeso}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite sua altura"
        keyboardType="numeric"
        onChangeText={setAltura}
      />

      <Button
        title="Calcular IMC"
        onPress={calcularIMC}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    justifyContent:'center',
    alignItems:'center',
  },

  titulo:{
    fontSize:22,
    marginBottom:20
  },

  input:{
    borderWidth:1,
    width:'80%',
    padding:10,
    marginBottom:15
  }
});