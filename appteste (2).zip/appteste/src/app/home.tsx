import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { useState } from 'react';

export default function Home() {

  const [idade, setIdade] = useState('');

  function checarIdade() {
    if (Number(idade) >= 18) {
      alert('Você é maior de idade');
    } else {
      alert('Você é menor de idade');
    }
  }

  return (
    <View style={styles.container}>

      <Text style={styles.titulo}>Verificar Maioridade</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite sua idade"
        keyboardType="numeric"
        onChangeText={setIdade}
      />

      <Button
        title="Verificar"
        onPress={checarIdade}
      />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    justifyContent:'center',
    alignItems:'center',
  },

  titulo:{
    fontSize:22,
    marginBottom:20
  },

  input:{
    borderWidth:1,
    width:'80%',
    padding:10,
    marginBottom:20
  }
});