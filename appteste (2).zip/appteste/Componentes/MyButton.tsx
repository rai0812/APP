import {Button} from 'react-native';

type Props = {
    title: string;
    onPress: () => void;
}

export default function MyButton( {title, onPress}: Props) {

    return ( 
        <Button onPress ={onPress} title= {title} />
    ); 
}